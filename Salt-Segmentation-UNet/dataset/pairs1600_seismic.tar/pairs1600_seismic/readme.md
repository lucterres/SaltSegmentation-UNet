# Dataset Aumentado — `pairs1600_seismic`

Conjunto de 1 600 pares imagem/máscara gerado com augmentações fisicamente coerentes para dados sísmicos.

---

## Origem do Projeto

| Campo            | Valor                                                           |
|------------------|-----------------------------------------------------------------|
| **Repositório**  | `GeomTransf` — Geometric Transformations for Ablation Study    |
| **Caminho**      | `d:\0Code\_phdSeismic\GeomTransf`                              |
| **Script gerador** | `scripts/generate_pairs_seismic.py`                          |
| **Saída gerada** | `output/pairs1600_seismic/`                                    |

---

## Base de Dados de Input

| Parâmetro         | Valor padrão                              |
|-------------------|-------------------------------------------|
| **Imagens**       | `D:\dataset\tgs-salt\train\images`        |
| **Máscaras**      | `D:\dataset\tgs-salt\train\masks`         |
| **Competição**    | TGS Salt Identification Challenge (Kaggle)|
| **Formato**       | PNG, 101 × 101 px (escala de cinza)       |

---

## Augmentações Aplicadas

### ✅ Transformações habilitadas

| Transformação              | Parâmetros                     | Justificativa                              |
|----------------------------|--------------------------------|--------------------------------------------|
| **Flip horizontal**        | p = 0,5                        | Simetria lateral aceitável em sísmica      |
| **Rotação leve**           | ±10°                           | Simula pequenas inclinações estruturais    |
| **Translação suave**       | ±5% da dimensão                | Shift espacial realista                    |
| **Escala discreta**        | 0,90 × – 1,10 ×               | Variação sutil de escala                   |
| **Ruído Gaussiano**        | σ variável (somente na imagem) | Simula ruído sísmico real                  |

### ❌ Transformações desabilitadas

| Transformação                 | Motivo                                          |
|-------------------------------|--------------------------------------------------|
| **Flip vertical**             | Altera polaridade física do sinal sísmico        |
| **Deformação elástica forte** | Apaga falhas e horizontes geológicos             |
| **Shear forte**               | Distorção não-física para dados sísmicos         |
| **Rotação grande (> ±10°)**   | Altera geometria estrutural de forma irreal      |

---

## Estrutura de Saída

```
output/pairs1600_seismic/
├── images/          # 1 600 imagens sísmicas augmentadas  (seismic_XXXX.png)
├── masks/           # 1 600 máscaras de sal correspondentes (seismic_XXXX.png)
└── pairs_log.csv    # Registro de cada par: fonte, índice e augmentações aplicadas
```

### Colunas de `pairs_log.csv`

| Coluna           | Descrição                                      |
|------------------|------------------------------------------------|
| `index`          | Índice sequencial do par                       |
| `output_image`   | Caminho relativo da imagem gerada              |
| `output_mask`    | Caminho relativo da máscara gerada             |
| `source_image`   | Nome do arquivo de imagem original             |
| `source_mask`    | Nome do arquivo de máscara original            |
| `augmentations`  | String descritiva das transformações aplicadas |

---

## Como Reproduzir

```bash
# A partir da raiz do projeto GeomTransf
python scripts/generate_pairs_seismic.py \
    --images D:\dataset\tgs-salt\train\images \
    --masks  D:\dataset\tgs-salt\train\masks  \
    --output output\pairs1600_seismic          \
    --count  1600                              \
    --seed   99
```

### Opções disponíveis

| Flag          | Padrão                              | Descrição                         |
|---------------|-------------------------------------|-----------------------------------|
| `--images`    | `D:\dataset\tgs-salt\train\images`  | Diretório de imagens originais    |
| `--masks`     | `D:\dataset\tgs-salt\train\masks`   | Diretório de máscaras originais   |
| `--output`    | `output\pairs1600_seismic`          | Diretório de saída                |
| `--count`     | `1600`                              | Número de pares a gerar           |
| `--seed`      | `99`                                | Semente aleatória (reprodutibilidade) |
| `--no-noise`  | —                                   | Desativa o ruído Gaussiano        |

---

## Dependências

Veja `requirements.txt` na raiz do projeto. Principais pacotes utilizados:

- `opencv-python` — transformações geométricas e I/O de imagens
- `numpy` — operações matriciais e geração de ruído
- `tqdm` — barra de progresso

---

*Gerado em: 2026-08-02 · Projeto: GeomTransf · Script: `scripts/generate_pairs_seismic.py`*
